﻿/*
 * Created by SharpDevelop.
 * User: edenfield-john
 * Date: 6/14/2016
 * Time: 9:24 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
//using System.Drawing;
//using System.Drawing.Imaging;


namespace DocEngine
{
	/// <summary>
	/// Description of MyClass.
	/// </summary>
	public class Document
	{
		public int ID { get; set; }
		public string Name { get; set; }
		public List<Page> Pages { get; set; }
		
		public Document(int id, string name)
		{
			ID = id;
			Name = name;
			Pages = new List<Page>();
			
		}

        public void RemovePage(int pagenum)
        {
            this.Pages.RemoveAt(pagenum);
        }

       


    }
}