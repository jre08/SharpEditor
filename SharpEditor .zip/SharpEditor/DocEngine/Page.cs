﻿/*
 * Created by SharpDevelop.
 * User: edenfield-john
 * Date: 6/14/2016
 * Time: 9:25 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.IO;

namespace DocEngine
{
	/// <summary>
	/// Description of Page.
	/// </summary>
	public class Page
	{
		public int PageNum { get; set; }
        public MemoryStream ImageStream { get; set; }
        //public string FileName { get; set; }  9/4/16
        public double ImageSize { get; set; }
        
		public Page(int pageNum, MemoryStream imageStream)
		{
			PageNum = pageNum;
			ImageStream = imageStream;
            ImageSize = imageStream.Capacity;
            // FileName = fileName;		 9/4/16
        }



    }
}
