﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MetroFramework.Forms;

namespace SharpEditor
{
    public partial class Form2 : MetroFramework.Forms.MetroForm
    {
        public Form2()
        {
            InitializeComponent();
            txt_Options_SavePath.Text = Properties.Settings.Default.SavePath;
        }

        private void metroTile1_Click(object sender, EventArgs e)
        {
            if ((folderBrowserDialogSaveFolder.ShowDialog() == DialogResult.OK))
            {
              txt_Options_SavePath.Text= folderBrowserDialogSaveFolder.SelectedPath;
                Properties.Settings.Default.SavePath = folderBrowserDialogSaveFolder.SelectedPath;
            }
        }
    }
}
