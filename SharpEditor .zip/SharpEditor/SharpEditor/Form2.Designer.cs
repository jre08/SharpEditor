﻿namespace SharpEditor
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.folderBrowserDialogSaveFolder = new System.Windows.Forms.FolderBrowserDialog();
            this.txt_Options_SavePath = new MetroFramework.Controls.MetroTextBox();
            this.metroTile1 = new MetroFramework.Controls.MetroTile();
            this.SuspendLayout();
            // 
            // txt_Options_SavePath
            // 
            // 
            // 
            // 
            this.txt_Options_SavePath.CustomButton.Image = null;
            this.txt_Options_SavePath.CustomButton.Location = new System.Drawing.Point(383, 1);
            this.txt_Options_SavePath.CustomButton.Name = "";
            this.txt_Options_SavePath.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txt_Options_SavePath.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txt_Options_SavePath.CustomButton.TabIndex = 1;
            this.txt_Options_SavePath.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txt_Options_SavePath.CustomButton.UseSelectable = true;
            this.txt_Options_SavePath.CustomButton.Visible = false;
            this.txt_Options_SavePath.Lines = new string[] {
        "metroTextBox1"};
            this.txt_Options_SavePath.Location = new System.Drawing.Point(23, 127);
            this.txt_Options_SavePath.MaxLength = 32767;
            this.txt_Options_SavePath.Name = "txt_Options_SavePath";
            this.txt_Options_SavePath.PasswordChar = '\0';
            this.txt_Options_SavePath.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_Options_SavePath.SelectedText = "";
            this.txt_Options_SavePath.SelectionLength = 0;
            this.txt_Options_SavePath.SelectionStart = 0;
            this.txt_Options_SavePath.Size = new System.Drawing.Size(405, 23);
            this.txt_Options_SavePath.TabIndex = 0;
            this.txt_Options_SavePath.Text = "metroTextBox1";
            this.txt_Options_SavePath.UseSelectable = true;
            this.txt_Options_SavePath.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txt_Options_SavePath.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroTile1
            // 
            this.metroTile1.ActiveControl = null;
            this.metroTile1.Location = new System.Drawing.Point(434, 127);
            this.metroTile1.Name = "metroTile1";
            this.metroTile1.Size = new System.Drawing.Size(61, 23);
            this.metroTile1.TabIndex = 2;
            this.metroTile1.Text = "Browse";
            this.metroTile1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTile1.UseSelectable = true;
            this.metroTile1.Click += new System.EventHandler(this.metroTile1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(545, 327);
            this.Controls.Add(this.metroTile1);
            this.Controls.Add(this.txt_Options_SavePath);
            this.Movable = false;
            this.Name = "Form2";
            this.Resizable = false;
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "Options";
            this.TopMost = true;
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialogSaveFolder;
        private MetroFramework.Controls.MetroTextBox txt_Options_SavePath;
        private MetroFramework.Controls.MetroTile metroTile1;
    }
}