﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;

namespace SharpEditor
{
    class SecurePassword
    {
          public static  string EncryptPassword(string Password)
        {

            byte[] passwordarray = Encoding.ASCII.GetBytes(Password);
            Properties.Settings.Default.Password = Convert.ToBase64String(passwordarray);
            return null; 

        }

       public static  string  decryptPassword()
        {

            byte[] passwordarray2 = Convert.FromBase64String(Properties.Settings.Default.Password);
            return ASCIIEncoding.ASCII.GetString(passwordarray2);
             

        }
        


    }

}
